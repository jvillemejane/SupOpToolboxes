# Times-Table-Cardioid

## check out my youtube channel: https://www.youtube.com/channel/UCjPk9YDheKst1FlAf_KSpyA

### enjoy the spaghetti code

## python main.py to run

![cardioid](https://user-images.githubusercontent.com/48150537/85911237-a642c480-b841-11ea-9faf-00725fbc8884.png)
